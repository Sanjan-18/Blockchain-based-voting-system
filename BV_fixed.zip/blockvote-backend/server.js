
import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";
import User from "./models/User.js";
import Election from "./models/Election.js";
import Vote from "./models/Vote.js";
import bcrypt from "bcryptjs";

dotenv.config();

const app = express();
app.use(express.json());
app.use\(cors\(\)\);
// Create default admin if not exists
(async ()=>{
 try{
  const admin=await User.findOne({role:'admin'});
  if(!admin){
    const hash=await bcrypt.hash('admin123',10);
    await User.create({id:1,firstName:'Admin',lastName:'User',email:'admin@admin.com',password:hash,role:'admin'});
    console.log('Admin created');
  }
 }catch(e){console.log(e)}
})();

mongoose.connect(process.env.MONGO_URI)
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

app.post("/api/register", async (req, res) => {
    try {
        const { firstName, lastName, email, password, age, phone, address } = req.body;

        const exists = await User.findOne({ email });
        if (exists) return res.json({ success: false, msg: "Email already exists" });

        const hashed = await bcrypt.hash(password, 10);
        const id = Date.now();

        await User.create({
            id,
            firstName,
            lastName,
            email,
            password: hashed,
            age,
            phone,
            address,
            role: "voter",
            isApproved: true
        });

        res.json({ success: true });
    } catch (err) {
        res.json({ success: false, msg: err.message });
    }
});

app.post("/api/login", async (req, res) => {
    const { email, password, role } = req.body;

    const user = await User.findOne({ email });
    if (!user) return res.json({ success: false, msg: "Invalid Email" });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.json({ success: false, msg: "Invalid Password" });

    if (user.role !== role)
        return res.json({ success: false, msg: "Role mismatch" });

    res.json({ success: true, user });
});

app.post("/api/location", async (req, res) => {
    const { email, location } = req.body;
    await User.updateOne({ email }, { location });
    res.json({ success: true });
});

app.post("/api/elections/create", async (req, res) => {
    try {
        await Election.create(req.body);
        res.json({ success: true });
    } catch (err) {
        res.json({ success: false, msg: err.message });
    }
});

app.get("/api/elections/all", async (req, res) => {
    const elections = await Election.find();
    res.json({ success: true, elections });
});

app.post("/api/elections/vote", async (req, res) => {
    try {
        const { electionId, candidateId, userId } = req.body;

        const already = await Vote.findOne({ electionId, userId });
        if (already)
            return res.json({ success: false, msg: "Already voted" });

        await Vote.create({
            electionId,
            candidateId,
            userId,
            timestamp: Date.now()
        });

        await Election.updateOne(
            { id: electionId, "candidates.id": candidateId },
            { $inc: { "candidates.$.votes": 1 } }
        );

        res.json({ success: true });
    } catch (err) {
        res.json({ success: false, msg: err.message });
    }
});

app.listen(process.env.PORT, () =>
    console.log(`Server running on port ${process.env.PORT}`)
);
