
import mongoose from "mongoose";

const ElectionSchema = new mongoose.Schema({
    id: Number,
    title: String,
    description: String,
    startDate: String,
    endDate: String,
    candidates: [
        {
            id: Number,
            name: String,
            party: String,
            votes: { type: Number, default: 0 }
        }
    ],
    createdBy: Number,
    geofencing: Object
});

export default mongoose.model("Election", ElectionSchema);
