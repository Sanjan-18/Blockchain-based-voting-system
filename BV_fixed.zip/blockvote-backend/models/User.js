
import mongoose from "mongoose";

const UserSchema = new mongoose.Schema({
    id: Number,
    firstName: String,
    lastName: String,
    email: { type: String, unique: true },
    password: String,
    role: { type: String, default: "voter" },
    age: Number,
    phone: String,
    address: String,
    isApproved: { type: Boolean, default: true },
    location: {
        latitude: Number,
        longitude: Number,
        city: String,
        state: String,
        country: String,
        timestamp: Number
    }
});

export default mongoose.model("User", UserSchema);
