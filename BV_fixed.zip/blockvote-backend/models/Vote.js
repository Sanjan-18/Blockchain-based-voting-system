
import mongoose from "mongoose";

const VoteSchema = new mongoose.Schema({
    electionId: Number,
    userId: Number,
    candidateId: Number,
    timestamp: Number
});

export default mongoose.model("Vote", VoteSchema);
